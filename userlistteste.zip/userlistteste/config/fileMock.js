module.exports = 'i-am-a-stubbed-file'
