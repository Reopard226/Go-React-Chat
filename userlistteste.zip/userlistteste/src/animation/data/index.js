import SimpleLoader from './simple-loader.json'
import Loader from './loader.json'
import CircleLoader from './loading-circle.json'

export default {
  SimpleLoader,
  Loader,
  CircleLoader
}
